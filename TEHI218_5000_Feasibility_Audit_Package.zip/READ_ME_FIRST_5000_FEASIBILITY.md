# TEHI-2026 Paper 218: 5,000-record clinical reconstruction feasibility audit

## Decision
**The original manuscript's Pima + unspecified public-data 5,000-record experiment cannot be verified or faithfully reconstructed from the available files.** Its exact sources, patient-level linkage (if any), harmonization rules, feature matrix, and original model artefacts are unavailable. No new dataset in this package should be represented as that original experiment.

Two scientifically usable *alternatives* exist, but neither reproduces the original:
- A fixed 5,000-record NHANES sample (4,306 negative; 694 positive), preserving approximate source prevalence.
- A fixed 5,000-record NHANES case-control subset (2,500 negative; 2,500 positive), matching the original manuscript's class counts **only**, not its participant population, feature definitions, outcome definition, performance, or claimed Pima contribution. A balanced sample changes prevalence and downstream precision/PPV interpretation.

## Verified actual files (local audit)
- Pima original: 768 rows; Outcome=0:500; Outcome=1:268; glucose, blood pressure, skin thickness, insulin, BMI, pedigree, pregnancies, age. No HbA1c, no cholesterol, and no participant ID.
- NHANES 5,000: 5,000 distinct participant IDs; Outcome=0:4306; Outcome=1:694; fasting glucose missing in 2,584 rows.
- NHANES balanced 5,000: 5,000 distinct participant IDs; Outcome=0:2500; Outcome=1:2500; fasting glucose missing in 2,630 rows.
- NHANES 5,000 subsets are **not** an addition to Pima. They are separate datasets of CDC survey participants.

## Why Pima + NHANES is not a defensible simple append
- Diabetes labels differ: Pima's Outcome from its diabetes benchmark versus NHANES' self-reported prior physician diagnosis (DIQ010). These outcomes are not identical and should not be silently pooled.
- Clinical features differ: both have Age and BMI; Pima glucose is a 2-hour OGTT measure and NHANES fasting glucose is a different measurement, so they cannot simply be renamed to a shared 'Glucose'. Pima has insulin, blood pressure, pregnancies, pedigree; NHANES here has HbA1c, waist, sex, race/ethnicity. Pima's HbA1c is not available.
- Pima sampling is a specific population of adult women; NHANES is a US civilian population survey of both sexes. Source differences could let a classifier recognize the source rather than diabetes status.
- Pima lacks participant identifiers for independent patient-wise validation. Large overlaps or multiple visits should not be invented.
- The Diabetic 130-US-hospitals data in the user's files comprise hospital encounters of people with diabetes; its readmission target is not a generic diabetes-positive/negative label, so it is not a direct 5,000-case replacement.
- BRFSS uses health-questionnaire indicators, not the manuscript's laboratory predictors.

## Explicit relevance to Reviewer 1
1. State diabetes *status* classification; do not claim incident diabetes, future complications or kidney/cardiovascular/neuropathy outcomes.
2. Give source-specific sample counts, inclusion/exclusion, missingness, label coding, demographics, and a provenance manifest.
3. Retinal dataset source, grades and imaging details remain a separate task.
4. Recalculate performance/ROC/confusion matrices from *the exact final selected dataset*; original 93.4% XGBoost cannot be carried over.
5. Keep training-only imputation/tuning and a held-out test; patient-wise IDs available for NHANES but not original Pima CSV.
6. Compare the four clinical models under identical splitting; any significance claim requires appropriate paired analysis.
7. Present two independent branches unless you possess genuinely matched patient-level clinical and retina inputs.
8. Mark IoT as proposed/simulated; don't claim hardware results.
9. Generate SHAP/LIME from whichever final trained clinical model is reported. Grad-CAM belongs to retinal CNN.
10. Describe recommendation logic and evidence; mark as decision support, not medical advice.
11. Restrict complication claims to outcomes actually measured (DR image classification only if trained).
12. Discuss privacy, survey bias, false negatives, and limits of external validation; NHANES data are public secondary data, not newly recruited patients.
13. Report actual hardware, run time, inference time, hyperparameters, versions.

## Reviewer 2
- No real IoT hardware validation demonstrated.
- Do not characterize independent public image datasets as a single unified patient cohort; report domain shift and truly performed external validation only.
- Benchmark retinal inference latency/memory on actual available hardware; do not reuse unverified RTX 3060 timing figures.

## Recommended minimum-change pathway
A. If original Pima + other-source 5,000-row file and its provenance can be recovered, audit and rerun that exact design. This is the only valid route to a faithful reconstruction.
B. If irretrievable, use the NHANES 5,000-row balanced subset **as an explicitly disclosed replacement clinical experiment**, retain 5,000 and 2500/2500 in Table 1, but revise source, predictors, target, model comparison, SHAP, reported scores, and limitations. Obtain conference/supervisor approval for a material dataset substitution. The 91.66% result from the full 30,634-row model **does not transfer** to either 5,000-row subset. Run new training.
C. Do not make up 4,232 records, report NHANES as self-collected patients, relabel 2-hour glucose as fasting glucose, or select a dataset after seeing accuracy to match the old 93.4% claim.

## Scope of audit
This package audits only files supplied/created in this conversation. Individual raw CDC downloaded XPT bytes were not re-downloaded in this audit. The NHANES provided manifest lists original CDC source files and selection logic; source verification can be independently repeated with the included source builder notebook. No performance evaluation of these 5,000-row subsets is claimed.
